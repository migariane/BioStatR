
#' Datos sobre pacientes diabeticos
#'
#' Archivo de datos con informacion sobre algunas variables antropometricas
#' denigraficas y clinicas de un conjunto de 94 diabeticos
#' (por compatibilidad se omiten acentos y caracteres no anglosajones)
#'
#' @format data frame con 27 variables y 94 casos:
#' \describe{
#'   \item{num}{numero de historia, }
#'   \item{edad}{edad del paciente, en anos}
#'   \item{grupo_edad}{categoria de edad del paciente, en anos}
#'   \item{sexo}{sexo del paciente}
#'   \item{peso}{peso del paciente, en kg}
#'   \item{talla}{talla del paciente, en cm}
#'   \item{imc}{indice de masa corporal de Quetelet}
#'   \item{tevol}{tiempo de evolucion de la enfermedad, en anos}
#'   \item{tabaco}{variable binaria, indicadora de si el paciente es fumador}
#'   \item{alcohol}{variable binaria, indicadora de si el paciente bebe alcohol o no}
#'   \item{ingca}{variable binaria, indicadora de si el paciente toma suficiente calcio o no}
#'   \item{acfis}{variable binaria, indicadora de la realizacion de actividad fisica regular}
#'   \item{retin}{presencia y gravedad de retinopatia}
#'   \item{nefro}{presencia y gravedad de nefropatia}
#'   \item{neuro}{presencia y gravedad de neuropatia}
#'   \item{hba1c}{porcentaje de hemoglobina glicosilada}
#'   \item{ca}{nivel de calcio, mg/dL}
#'   \item{p}{nivel de fosforo, mg/dL}
#'   \item{cr}{nivel de creatinina, mg/dL}
#'   \item{pthm}{nivel de hormona paratiroidea media, ng/ml}
#'   \item{pthi}{nivel de hormona paratiroidea intacta, pg/ml}
#'   \item{bmdcue}{densidad de masa osea en el cuello del femur}
#'   \item{szl24}{densidad de masa osea tipificada en l24}
#'   \item{szl24}{densidad de masa osea tipificada en el triangulo de Ward}
#'   \item{szcue}{densidad de masa osea tipificada en el cuello del femur}
#'   \item{osteo_cue}{presencia de osteoporosis en el cuello del femur}
#'   \item{osteo_tri}{presencia de osteoporosis en el triangulo}
#'
#' }
#' @source \url{http://www.ugr.es/local/bioest/osteo.RData}
"osteo"
